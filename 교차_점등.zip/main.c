/*
 * Cross_light.c
 *
 * Created: 2021-04-24 오후 6:13:41
 * Author : xkakr
 */ 

#define F_CPU 16000000L		//클록 상수 설정		
#include <avr/io.h>			//레지스터 이름 정의 포함
#include <util/delay.h>		//시간 지연 함수 _delay_ms 원형

int main(void)
{
	/* Replace with your application code */
	DDRB = 0x01; //0b00100000 대치, LED가 연결된 필을 출력으로 설정
	DDRD = 0x80;
	
	while (1) //무한 루프
	{
		PORTD = 0x00;
		PORTB = 0x01;		
		_delay_ms(1000);
		PORTB = 0x00;
		PORTD = 0x80;		
		_delay_ms(1000);
	}
	
	return 1;
}