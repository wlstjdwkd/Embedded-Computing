#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

ISR(PCINT0_vect)
{
	if(PINB & 0x20){
		PORTD = 0x04;
		PORTB = 0x2F;
	}
	else{
		uint8_t on_off = 0;
		for (int i=0;i<8;i++)
		{
			on_off |= 0x80 >> i;
			PORTD = ~((on_off << 4) | 0x04);
			PORTB = ~((on_off >> 4) | 0x20);
			
			_delay_ms(100);
		}
	}
}
ISR(PCINT2_vect)
{
	if(PIND & 0x04){
		PORTD = 0xF4;
	}
	else{
		uint8_t on_off = 0;
		for(int i=0; i<8; i++){
			on_off |= 0x01 <<i;
			PORTD = ~((on_off << 4) | 0x04);
			PORTB = ~((on_off >> 4) | 0x20);
			
			_delay_ms(100);
		}
		PORTB = 0x2F;
		PORTD = 0xF4;
	}
}

void INIT_PORT(void)
{
	DDRB = 0x0F;
	PORTB = 0x2F;

	DDRD = 0xF0;
	PORTD = 0xF4;
}


void INIT_PCINT0(void)
{
	PCICR |= (1 << PCIE0);        
	PCMSK0 |= (1 << PCINT5);    
	
	sei();                        
}
void INIT_PCINT2(void)
{
	PCICR |= (1 << PCIE2);        
	PCMSK2 |= (1 << PCINT18);    
	
	sei();                        
}

int main()
{
	INIT_PORT();        
	INIT_PCINT0();        
	INIT_PCINT2();

	while(1){}            
}