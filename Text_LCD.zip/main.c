
#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include "TEXT_LCD.h"

// 모드 설정을 위해 전역 변수로 선언해주어야 한다.
// 4 : 4비트 모드, 8 : 8비트 모드
uint8_t MODE = 4;
uint8_t toggle = 0;

// ADC 레지스터 초기화
void ADC_INIT(unsigned char channel)
{
	ADMUX = 0x40;
	ADCSRA |=0x07;
	ADCSRA |= (1 << ADEN);
	ADCSRA |= (1 << ADATE);
	ADMUX |= ((ADMUX & 0xE0) | channel);
	ADCSRA |= (1 <<ADSC);
}

// 아날로그 값 read
int read_ADC(void)
{
	while(!(ADCSRA & ( 1 << ADIF)));
	return ADC;
}

void Timer_init(void){
	TCCR0B |= (1 << CS02) | (1 << CS00);
}

int main(void)
{
	LCD_init();        // 텍스트 LCD 초기화
	ADC_INIT(0);
	_delay_ms(50);
	srand(read_ADC());
	LCD_clear();
	
	DDRB |= 0x00;
	PORTB |= 0x20; // 풀업 저항 사용
	
	int read, randomnum,temperature;
	float input_voltage;
	
	while(1){
		if((PINB>>5)&0x01==0x01){
			ADC_INIT(2);
			_delay_ms(50);
			read = read_ADC();
			input_voltage = read * 5.0 / 1023.0;
			temperature = input_voltage * 100;
			
			randomnum=rand()%2000+1;
			
			LCD_clear();        // 화면 지움
			LCD_write_string("LM35 : ");
			char temp[2];
			int j=0;
			for(j;j<2;j++){
				temp[j]=temperature%10;
				temperature=temperature/10;
				if(temperature<1) break;
			}
			for(j;j>=0;j--){
				LCD_write_data(temp[j]+'0');
			}
			
			LCD_goto_XY(1,0);
			LCD_write_string("Random : ");
			char num[4];
			int i=0;
			for(i;i<4;i++){
				num[i]=randomnum%10;
				randomnum=randomnum/10;
				if(randomnum<1) break;
			}
			for(i;i>=0;i--){
				LCD_write_data(num[i]+'0');
			}
			}else{
			ADC_INIT(4);
			_delay_ms(50);
			int cds=read_ADC();
			
			LCD_clear();        // 화면 지움
			LCD_write_string("CDS : ");
			char cdschar[4];
			int j=0;
			for(j;j<4;j++){
				cdschar[j]=cds%10;
				cds=cds/10;
				if(cds<1) break;
			}
			for(j;j>=0;j--){
				LCD_write_data(cdschar[j]+'0');
			}
			LCD_goto_XY(1,0);
			LCD_write_string("20170526 JSBANG");
		}
		_delay_ms(500);
	}
	return 1;
}